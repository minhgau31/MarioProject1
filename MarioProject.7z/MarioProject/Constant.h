#pragma once
#define SCREEN_WIDTH 640
#define SCREEN_HEIGHT 480